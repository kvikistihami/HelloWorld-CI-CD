//////////////////////////////////////////////////////////////////////////
//
// pgAdmin III - PostgreSQL Tools
// Copyright (C) 2002 - 2016, The pgAdmin Development Team
// This software is released under the PostgreSQL Licence
//
// gqbObject.h -
//
//////////////////////////////////////////////////////////////////////////

#ifndef HDOBJECT_H
#define HDOBJECT_H

class hdObject : public wxObject
{
public:
	hdObject() {};
};
#endif
