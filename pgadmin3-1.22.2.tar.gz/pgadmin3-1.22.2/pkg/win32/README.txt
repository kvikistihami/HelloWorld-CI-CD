This directory contains the pgAdmin3 installer for Windows. To build the
installer, you will need a copy of WiX installed somewhere in your system
path. The installer has been tested with WiX version 3.0.2420 only at the
time writing. WiX may be downloaded from:

  http://sourceforge.net/projects/wix/.
